#!/bin/bash

LOG="/var/log/backup_full.log"
CANT_ARGUMENTOS=$#

if [ $CANT_ARGUMENTOS -eq 1 ] && ( [ $1 = "-h" ] || [ $1 = "--help" ] ); then
    echo -e "Uso: backup_full <path> <path>\nEste script es utilizado para realizar un backup en formato tar de un directorio entero.\n\nArgumento 1: Path origen del directorio a realizar el backup\nArgumento 2: Path destino donde se guardara el backup generado\n\nEjemplo: backup_full /etc /tmp";
    exit;
elif [ $CANT_ARGUMENTOS -eq 2 ]; then
    if ( [ ! -d $1 ] || [ ! -d $2 ]);then
        if [ ! -d $1 ]; then
        ERROR_MSG="Error: \"$1\" no es un directorio valido";
        echo $ERROR_MSG
        echo $(date -u) $ERROR_MSG >> $LOG
        fi
        if [ ! -d $2 ]; then
        ERROR_MSG="Error: \"$2\" no es un directorio valido";
        echo $ERROR_MSG
        echo $(date -u) $ERROR_MSG >> $LOG
        fi
        exit;
    fi
else
    echo "Error. Utilice -h o --help para más información sobre el programa"
    exit;
fi

DIR_TO_BACKUP=$1

FILENAME=`echo $1 | sed 's/^\.//' | sed 's/^\///' | sed 's/\/$//' | tr / -`"_bkp_"`date +%Y%m%d`;
BACKUP_OUTPUT="`echo $2 | sed 's/\/$//'`/$FILENAME.tar.gz"

tar -cPzf $BACKUP_OUTPUT $DIR_TO_BACKUP

echo $(date -u) "Backup finalizado del directorio: \"$1\". Archivo generado: \"$BACKUP_OUTPUT\"" >> $LOG
